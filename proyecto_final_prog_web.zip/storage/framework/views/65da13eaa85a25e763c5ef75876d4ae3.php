
<?php $__env->startSection('content'); ?>

<div class="Content__portada">
    <div class="container">
        <div class="Content__portada--container">
            <div class="Content__portada--details">
                <div class="Content__portada--details-slogan">
                    <p>Lee un libro y obtendrás conocimiento</p>
                </div>
                <div class="Content__portada--details-title">
                    <h2>Lee, <br /> Aprende y Explora!</h2>
                </div>
                <div class="Content__portada--details-description">
                    <p>Imagina que te sumerges en un mundo completamente fantasioso, con todo tipo de escenarios que no podrás creer, un libro es capaz de transportarte a este tipo de mundos.</p>
                </div>
                <div class="Content__portada--details-buttons">
                    <button>Comienza a leer</button>
                    <a href="<?php echo e(route('contactos.index')); ?>"><button>Contactános</button></a>
                </div>
            </div>
            <div class="Content__portada--banner">
                <img src="./images/port-banner.png" alt="">
            </div>
        </div>
    </div>
</div>
<div class="Content__raffles">
    <div class="container">
        <div class="Content__raffles--tabs">
            <div class="Content__raffles--tabs-tab activeTab" navFor="Libros">
                <h4>Libros</h4>
            </div>
            <div class="Content__raffles--tabs-tab" navFor="Autores">
                <h4>Autores</h4>
            </div>
        </div>
        <form action="<?php echo e(route('library.index')); ?>">
            <div class="Content__raffles--search">
                <input type="search" name="search" id="search" placeholder="Buscar... (Nota: Filtrar por Titulo para libros y por Nombre para autores.)" value="<?php echo e($search); ?>">
                <button type="submit"><img src="./images/search-icon-body.png" alt=""></button>
            </div>
        </form>
        <div class="Content__raffles--container Libros bodyActive">
            <?php if( count($libros) > 0): ?>
                <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="Content__raffles--raffleCard">
                        <div class="Content__raffles--raffleCard-foundation">
                            <p><?php echo e($libro->titulo); ?></p>
                        </div>
                        <div class="Content__raffles--raffleCard-icon">
                            <img src="./images/book.png" alt="">
                        </div>
                        <div class="Content__raffles--raffleCard-name">
                            <?php $publicador = App\Models\publicadores::where('id_pub', $libro->id_pub)->first(); ?>
                            <h4><?php echo e($publicador->nombre_pub); ?></h4>
                        </div>
                        <div class="Content__raffles--raffleCard-date">
                            <p><?php echo e($libro->tipo); ?></p>
                        </div>
                        <div class="Content__raffles--raffleCard-numbers">
                            <div class="raffles__raffleCard--numbers-number">
                                <p>Ventas: <?php echo e($libro->total_ventas ?? 0); ?></p>
                            </div>
                        </div>
                        <div class="Content__raffles--raffleCard-numAmount">
                            <p>Precio: $<?php echo e($libro->precio); ?></p>
                        </div>
                        <div class="Content__raffles--raffleCard-availableNumbers">
                            <p>Avance: <?php echo e($libro->avance); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="Content__raffles--raffleCard-foundation" style="text-align: left;">
                    <p>No hay libros con este criterio de búsqueda.</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="pagination paginationLibros paginationActive">
            <?php echo e($libros->links()); ?>

        </div>

        <div class="Content__raffles--container Autores">
            <?php if(count($autores) > 0): ?>
                <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="Content__raffles--raffleCard">
                        <div class="Content__raffles--raffleCard-foundation">
                            <p><?php echo e($autor->nombre); ?> <?php echo e($autor->apellido); ?></p>
                        </div>
                        <div class="Content__raffles--raffleCard-icon">
                            <img src="./images/writer.png" alt="">
                        </div>
                        <div class="Content__raffles--raffleCard-name">
                            <h4><?php echo e($autor->ciudad); ?></h4>
                        </div>
                        <div class="Content__raffles--raffleCard-date">
                            <p><?php echo e($autor->telefono); ?></p>
                        </div>
                        <div class="Content__raffles--raffleCard-numbers">
                            <div class="raffles__raffleCard--numbers-number">
                                <p><?php echo e($autor->pais); ?></p>
                            </div>
                            <div class="raffles__raffleCard--numbers-number">
                                <p><?php echo e($autor->estado); ?></p>
                            </div>
                            <div class="raffles__raffleCard--numbers-number">
                                <p><?php echo e($autor->ciudad); ?></p>
                            </div>
                        </div>
                        <div class="Content__raffles--raffleCard-numAmount">
                            <p>Código postal: <?php echo e($autor->cod_postal); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="Content__raffles--raffleCard-foundation" style="text-align: left;">
                    <p>No hay autores con este criterio de búsqueda.</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="pagination paginationAutores">
            <?php echo e($autores->links()); ?>

        </div>
    </div>
</div>
<div class="Content__testimonials">
    <div class="container">
        <div class="Content__testimonials--container">
            <div class="Content__testimonials--title">
                <h2>Ellos dieron su opinión sobre los libros</h2>
            </div>
            <div class="Content__testimonials--slider">
                <div class="Content__testimonials--slide">
                    <div class="Content__testimonials--slide-text">
                        <p>Es íncreible, al principio no era muy fan de leer pero esta página me convenció y vaya que fue una excelente decisión, he pasado una de las mejores experiencias de mi vida leyendo mi primer libro :D </p>
                    </div>
                    <div class="Content__testimonials--slide-name">
                        <h4>Max Sulivan - 30/11/2023</h4>
                    </div>
                </div>
            </div>
            <div class="Content__testimonials--arrows">
                <div class="Content__testimonials--arrows-leftArrow">
                    <img src="./images/left-arrow.png" alt="">
                </div>
                <div class="Content__testimonials--arrows-rightArrow">
                    <img src="./images/right-arrow.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="Content__characteristics">
    <div class="container">
        <div class="Content__characteristics--container">
            <div class="Content__characteristics--item">
                <div class="Content__characteristics--icon">
                    <img src="./images/credit-card-icon.png" alt="">
                </div>
                <div class="Content__characteristics--details">
                    <div class="Content__characteristics--details-title">
                        <h4>Abre tu mente</h4>
                    </div>
                    <div class="Content__characteristics--details-description">
                        <p>Te nutre de conocimiento.</p>
                    </div>
                </div>
            </div>
            <div class="Content__characteristics--item">
                <div class="Content__characteristics--icon">
                    <img src="./images/credit-card-icon.png" alt="">
                </div>
                <div class="Content__characteristics--details">
                    <div class="Content__characteristics--details-title">
                        <h4>Pasatiempo sano</h4>
                    </div>
                    <div class="Content__characteristics--details-description">
                        <p>No daña el entorno ni tu cuerpo.</p>
                    </div>
                </div>
            </div>
            <div class="Content__characteristics--item">
                <div class="Content__characteristics--icon">
                    <img src="./images/credit-card-icon.png" alt="">
                </div>
                <div class="Content__characteristics--details">
                    <div class="Content__characteristics--details-title">
                        <h4>Ejercita tu cerebro</h4>
                    </div>
                    <div class="Content__characteristics--details-description">
                        <p>Te mantiene atento beneficiando tu cerebro.</p>
                    </div>
                </div>
            </div>
            <div class="Content__characteristics--item">
                <div class="Content__characteristics--icon">
                    <img src="./images/credit-card-icon.png" alt="">
                </div>
                <div class="Content__characteristics--details">
                    <div class="Content__characteristics--details-title">
                        <h4>Sumamente divertido</h4>
                    </div>
                    <div class="Content__characteristics--details-description">
                        <p>Que la imaginación vuele, esa es la mejor parte.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto_final_prog_web\resources\views\libros\index.blade.php ENDPATH**/ ?>